vim.g.did_load_filetypes = 1

local hooks = require "core.hooks"

hooks.add("install_plugins", function(use)
   use {
      "jose-elias-alvarez/null-ls.nvim",
      after = "nvim-lspconfig",
      config = function()
         require("custom.plugins.null-ls").setup()
      end,
   }

   use {
      "Pocco81/TrueZen.nvim",
      cmd = {
         "TZAtaraxis",
         "TZMinimalist",
         "TZFocus",
      },
      config = function()
         require("true-zen").setup()
      end
   }

   use {
      'ruifm/gitlinker.nvim',
      requires = 'nvim-lua/plenary.nvim',
      config = function()
         require("gitlinker").setup{
            opts = {
               action_callback = function(url)
                  -- yank to unnamed register
                  vim.api.nvim_command('let @" = \'' .. url .. '\'')
                  -- copy to the system clipboard using OSC52
                  vim.fn.OSCYankString(url)
               end,
            },
         }
      end,
   }

   use "f-person/git-blame.nvim"      
   use "christoomey/vim-tmux-navigator"
   use "nathom/filetype.nvim"
   use "tversteeg/registers.nvim"
      
   use {
      "ojroques/vim-oscyank",
      config = function()
         if vim.env.SSH_CLIENT or vim.env.SSH_TTY then
            vim.cmd("autocmd!")
            vim.cmd("autocmd TextYankPost * OSCYankReg +<CR>")
         end
      end
   }
end)
