local M = {}
M.options, M.ui, M.mapping, M.plugins = {}, {}, {}, {}

M.plugins = {
  status = {
    neoscroll = true,
    colorizer = true,
    truezen = true,
  },
  options = {
    nvimtree = {
      enable_git = 1,
    },
    lspconfig = {
      setup_lspconf = "custom.plugins.lspconfig"
    }
  },
  user = {
    ["goolord/alpha-nvim"] = {
        disable = false,
    },
    ["fatih/vim-go"] = {
        disable = false,
    },
    ["simrat39/rust-tools.nvim"] = {
        after = "nvim-lspconfig",
        config = function()
            require("rust-tools").setup({})
        end
    }
  },
}

M.ui = {
  theme = "gruvchad",
}

M.options = {

  tabstop = 4,

  user = function ()
    vim.opt.clipboard = "unnamedplus"
    vim.opt.ruler = true
    vim.opt.relativenumber = true
    vim.opt.expandtab = true
    vim.opt.shiftwidth = 4
    vim.opt.smartindent = true
    vim.opt.tabstop = 4
    vim.opt.softtabstop = 4
    vim.opt.history = 500
    vim.opt.guifont="MonoLisa NF:h14"
    vim.g.neovide_cursor_vfx_mode="railgun"
    -- vim.g.neovide_remember_window_size=true
    vim.g.neovide_fullscreen = true
  end,
}

return M
